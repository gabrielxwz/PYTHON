"""
Questão 06

• Escreva um programa que atenda as requisições abaixo e imprma todos os resultados:

01. crie uma nova lista só com os numeros pares.
02. crie uma nova lista só com os numeros impares.
03. crie uma nova lisa só com os multiplos de 2.
04. some todos os itens da "lista" 
05. informe quais valores se repetem

"""

lista = [10,11,20,22,30,33,40,11,50,55,60,66,70,22,80,88,90,99]