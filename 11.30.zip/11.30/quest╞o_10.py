"""
Questão 10

• Escreva uma função que calcule o fatorial de um numero e lembre de imprmir todos os resultados:

01. o numero  deve ser solicitado ao usaurio

"""
