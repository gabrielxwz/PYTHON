"""
Questão 08

• Escreva uma função que calcule o tempo de viagem de uma pessoa lembre de imprmir todos os resultados:

01. peça a distancia e a velocidade media
02. a formula é: distância / velocidade média(hora)
03. não esqueça de limitar a respota em apenas duas casas decimais 

"""